module.exports = {
    mongoURl: "mongodb+srv://bhushanexe:bhushan@cluster0.sbnyqbr.mongodb.net/?retryWrites=true&w=majority"
}